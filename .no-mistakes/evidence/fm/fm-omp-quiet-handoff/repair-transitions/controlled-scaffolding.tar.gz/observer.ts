import { appendFileSync, writeFileSync } from 'node:fs';
const state = `${process.env.FM_HOME}/state`;
const log = (event: unknown) => appendFileSync(`${state}/events.jsonl`, `${JSON.stringify(event)}\n`);
export default function(pi: any) {
  writeFileSync(`${state}/.lock`, `${process.pid}\n`);
  pi.registerProvider('acceptance-local', {
    baseUrl: process.env.ACCEPTANCE_BASE_URL,
    apiKey: 'isolated-local-fixture',
    api: 'openai-completions',
    models: [{ id: 'deterministic', name: 'Acceptance Local', reasoning: true, input: ['text'], cost: {input:0, output:0, cacheRead:0, cacheWrite:0}, contextWindow: 65536, maxTokens: 128 }],
  });
  pi.on('session_start', async (_event: any, ctx: any) => {
    writeFileSync(`${state}/.lock`, `${process.pid}\n`);
    const model = ctx.modelRegistry.find('acceptance-local', 'deterministic');
    if (model) await pi.setModel(model);
    log({event: 'session_start', pid: process.pid, model: !!model, ui: Object.keys(ctx.ui)});
  });
  for (const event of ['before_agent_start', 'message_start', 'agent_end', 'session_shutdown']) {
    pi.on(event, (data: any) => log({event, data}));
  }
  pi.registerCommand('accept-input', {
    description: 'Set an isolated acceptance draft through the actual editor API.',
    handler: async (args: string, ctx: any) => {
      const value = JSON.parse(args || '""');
      ctx.ui.setEditorText(value);
      log({event:'editor_set', value});
    },
  });
  pi.registerCommand('accept-inspect', {
    description: 'Observe the isolated editor draft.',
    handler: async (_args: string, ctx: any) => log({event:'editor_read', value:ctx.ui.getEditorText()}),
  });
}
