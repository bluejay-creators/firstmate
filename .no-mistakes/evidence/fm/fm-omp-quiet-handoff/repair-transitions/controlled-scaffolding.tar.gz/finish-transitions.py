#!/usr/bin/env python3
"""One isolated native omp runtime; four controlled restoration transitions."""
import hashlib, http.server, json, os, pathlib, queue, shutil, signal, subprocess, threading, time
ROOT = pathlib.Path.cwd()
V = ROOT / '.validation-7007'
HOME = V / 'home'
STATE = HOME / 'state'
EVIDENCE = pathlib.Path('/Users/jubin/Git/bluejay-creators/.nm7007/evidence/01M5YYVGAPA7RVXGCG54HQCZKN') / 'repair-transitions'
EVIDENCE.mkdir(exist_ok=True)
results = []
product = None
threads = []
rpc = queue.Queue()
raw = []
requests = []
started = time.monotonic()

def wait_for(predicate, label, seconds=20):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if predicate(): return
        if product is not None and product.poll() is not None:
            raise AssertionError('native omp exited before ' + label)
        time.sleep(.025)
    raise AssertionError('timeout: ' + label)

def lines(path):
    return path.read_text().splitlines() if path.exists() else []

def pid_alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False

def events():
    return [json.loads(s) for s in lines(STATE / 'events.jsonl')]

def user_starts():
    return sum(e.get('event') == 'before_agent_start' for e in events())

def send(message):
    product.stdin.write(json.dumps(message) + '\n')
    product.stdin.flush()

def command(text):
    send({'type':'prompt','message':text})

def run(args, env, seconds=10):
    return subprocess.run(args, env=env, cwd=ROOT, text=True, capture_output=True, timeout=seconds, start_new_session=True)

def memory():
    out = subprocess.check_output(['vm_stat'], text=True)
    values = {}
    for row in out.splitlines():
        for key in ['Pages free', 'Pages occupied by compressor', 'Swapouts']:
            if row.startswith(key + ':'): values[key] = int(row.split(':')[1].strip().rstrip('.'))
    return values

class Local(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        size = int(self.headers.get('Content-Length', '0'))
        self.rfile.read(size)
        requests.append({'unexpected_provider_request':True})
        self.send_response(500); self.end_headers(); self.wfile.write(b'Unexpected model turn in silent transition acceptance')
    def log_message(self, *args): pass

server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Local)
threading.Thread(target=server.serve_forever, daemon=True).start()
# Use only the recorded disposable home, never the operator's environment/state.
env = {k: os.environ[k] for k in ['PATH','LANG','LC_ALL','TERM','TMPDIR'] if k in os.environ}
env.update({
    'HOME':str(V/'os-home'), 'XDG_CACHE_HOME':str(V/'cache'),
    'PI_CODING_AGENT_DIR':str(V/'agent'), 'FM_HOME':str(HOME),
    'FM_ROOT_OVERRIDE':str(V/'fixture'), 'FM_TEST_ROOT':str(ROOT),
    'FM_STATE_OVERRIDE':str(STATE), 'FM_CONFIG_OVERRIDE':str(HOME/'config'),
    'ACCEPTANCE_BASE_URL':'http://127.0.0.1:%s/v1'%server.server_port,
    'FM_OMP_ARM_READY_TIMEOUT_MS':'12000', 'FM_WATCH_ARM_RETIRE_TIMEOUT_MS':'3000',
    'FM_WATCH_REARM_RETRY_LIMIT':'1', 'FM_WATCH_REARM_RETRY_BASE_MS':'25',
    'FM_WATCH_REARM_RETRY_MAX_MS':'25', 'FM_POLL':'0.2',
    'FM_CHECK_INTERVAL':'999999', 'FM_HEARTBEAT':'999999',
    'FM_ESCALATE_BATCH_SECS':'999999', 'NO_COLOR':'1',
})
daemon_env = dict(env, FM_ROOT_OVERRIDE=str(ROOT))
initial_events = len(events())
mem_before = memory()
# Previous product and test actor were explicitly recorded as exited.
for pid in [32948, 96318]:
    try: os.kill(pid, 0)
    except ProcessLookupError: pass
    else: raise AssertionError('recorded exited pid is now occupied; refusing ownership inference')
# Preserve stale recovery state privately until final cleanup; do not remove any live lock.
assert not (STATE/'.watch.lock').exists(), 'recorded home still has a watcher lock'
reconciled = V/'reconciled'
reconciled.mkdir(exist_ok=True)
for name in ['.watcher-down','.last-watcher-beat','.last-check','.last-heartbeat']:
    p = STATE/name
    if p.exists(): shutil.move(str(p),str(reconciled/name))
(STATE/'.afk').write_text('quiet\n')
(STATE/'live-case').write_text('arm-readiness\n')
(V/'home/state/scenarios/arm-readiness').mkdir(exist_ok=True)

def read_output(stream, tag):
    for line in stream:
        raw.append((tag,line))
        if tag == 'stdout':
            try: rpc.put(json.loads(line))
            except ValueError: pass

try:
    product = subprocess.Popen([
        shutil.which('omp'), '--mode','rpc','--no-ui','--no-session',
        '--no-tools','--no-lsp','--no-pty','--no-extensions','--no-skills',
        '--no-rules','--no-title','--config',str(V/'config.yml'),
        '--extension',str(V/'observer.ts'),
        '--extension',str(ROOT/'.omp/extensions/fm-primary-omp-watch.ts'),
        '--system-prompt','Isolated local acceptance. No external actions.',
    ], cwd=ROOT, env=env, stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,start_new_session=True)
    (V/'repair-product.pid').write_text(str(product.pid)+'\n')
    for stream,tag in [(product.stdout,'stdout'),(product.stderr,'stderr')]:
        t=threading.Thread(target=read_output,args=(stream,tag),daemon=True);t.start();threads.append(t)
    wait_for(lambda:len(events())>initial_events and any(e.get('event')=='session_start' for e in events()[initial_events:]), 'native primary session start', 40)
    wait_for(lambda:str(product.pid) in lines(STATE/'.omp-watch-extension-loaded')[1:], 'current native extension marker', 10)
    assert (STATE/'.lock').read_text().strip() == str(product.pid)
    for mode,transition in [('arm','readiness'),('host','readiness'),('arm','confirmation'),('host','confirmation')]:
        case = mode+'-'+transition
        d = STATE/'scenarios'/case; d.mkdir(exist_ok=True)
        assert not (STATE/'.watch.lock').exists(), 'prior owned watcher was not retired'
        (STATE/'live-case').write_text(case+'\n')
        if mode == 'host': (HOME/'config/supervision-host').touch()
        else: (HOME/'config/supervision-host').unlink(missing_ok=True)
        if transition == 'confirmation': (d/'confirmation').touch()
        # Retain the original queue/escalation history; only require this check's delta.
        assert not (STATE/'.wake-queue').read_text().strip(), 'previous queue was not consumed'
        for name in ['.watcher-down','.last-watcher-beat']:
            (STATE/name).unlink(missing_ok=True)
        baseline = user_starts()
        (STATE/'.afk').unlink()
        command('/fm-watch-arm-omp')
        arm_count = lambda:sum(s.startswith('arm=') for s in lines(d/'arm.log'))
        wait_for(lambda:arm_count()==1, case+' predecessor')
        (d/'fire').touch()
        wait_for(lambda:arm_count()==2, case+' successor starts before quiet')
        if transition == 'readiness': (STATE/'.afk').write_text('quiet\n')
        (d/'ready').touch()
        wait_for(lambda:(d/'published').exists(), case+' successor readiness')
        wait_for(lambda:(d/'retiring').exists(), case+' owned retirement')
        assert (STATE/'.afk').read_text().strip() == 'quiet'
        confirm = lines(d/'arm.log').count('confirm')
        assert confirm == (1 if transition=='confirmation' else 0), 'wrong handling confirmation boundary'
        episode = 'handling' if transition=='confirmation' else 'downtime'
        assert (STATE/'.watcher-down').read_text().startswith('announced:'+episode+':'), 'recovery episode lost before retirement'
        assert case+' original check' in (STATE/'.wake-queue').read_text(), 'pending check lost before retirement'
        blocked = run([str(ROOT/'bin/fm-watch.sh')],daemon_env)
        assert blocked.returncode == 0 and 'watcher: already running' in blocked.stdout, 'successor did not hold daemon lock before retirement'
        (d/'retired').touch()
        wait_for(lambda:not (STATE/'.watch.lock').exists(), case+' owned watcher lock release')
        watcher_pid = int((d/'owned-watcher.pid').read_text())
        wait_for(lambda:not pid_alive(watcher_pid), case+' owned watcher exit')
        wake = run([str(ROOT/'bin/fm-watch.sh')],daemon_env)
        assert wake.returncode == 0 and wake.stdout.strip() == 'check: rearm-resurface', 'original wake did not resurface without a second wake'
        consumed=run(['bash','-c','. "$FM_TEST_ROOT/bin/fm-supervise-daemon.sh"; LOG="$FM_HOME/state/daemon.log"; handle_durable_wakes "$1" "$FM_HOME/state"','_',wake.stdout.strip()],daemon_env)
        assert consumed.returncode == 0, 'daemon consumer failed'
        assert not (STATE/'.wake-queue').read_text().strip(), 'daemon left queued check'
        assert case+' original check' in (STATE/'.subsuper-escalations').read_text(), 'daemon did not route original check'
        time.sleep(.6)
        assert user_starts() == baseline and not requests, 'quiet transition woke native main'
        assert arm_count()==2, 'unexpected extra arm during quiet ownership'
        assert not (STATE/'extensions/omp-primary-watch/session-replacement-actionable.json').exists(), 'delivered handoff retained replacement replay'
        if mode == 'host': assert len(lines(d/'host.log')) == 2, 'host restoration path was not selected'
        results.append({'case':case,'result':'passed','native_primary':True,'controlled_arm_or_host':True,'real_watcher_and_daemon_consumer':True,'queued_check_retained_until_retirement':True,'recovery_episode':episode,'owned_watcher_retired':True,'daemon_consumed_without_second_wake':True,'main_model_turns':0,'replacement_replay_record':False,'host_launches':len(lines(d/'host.log')) if mode=='host' else 0})
        (EVIDENCE/(case+'.json')).write_text(json.dumps(results[-1],indent=2)+'\n')
        print('PASS '+case+': owned retirement; original check consumed; no main turn',flush=True)
    # A fresh attended arm command on the same runtime must not replay a completed quiet wake.
    (STATE/'live-case').write_text('after-transitions\n')
    d=STATE/'scenarios/after-transitions';d.mkdir(exist_ok=True)
    (HOME/'config/supervision-host').unlink(missing_ok=True)
    (STATE/'.afk').unlink()
    command('/fm-watch-arm-omp')
    wait_for(lambda:len(lines(d/'arm.log'))==1,'attended arm without replay')
    time.sleep(.6)
    assert user_starts()==baseline and not requests,'quiet wake replayed on attended arm'
    (STATE/'.afk').write_text('quiet\n')
finally:
    # Release only the barriers belonging to this driver's controlled children.
    for d in (STATE/'scenarios').iterdir():
        if d.name in ['arm-readiness','host-readiness','arm-confirmation','host-confirmation','after-transitions']:
            (d/'retired').touch()
    if product is not None and product.poll() is None:
        product.send_signal(signal.SIGINT)
        try: product.wait(timeout=10)
        except subprocess.TimeoutExpired:
            product.terminate()
            try: product.wait(timeout=10)
            except subprocess.TimeoutExpired:
                product.kill(); product.wait(timeout=5)
    server.shutdown()
    # Raw RPC output is private throwaway runtime data, never exported as evidence.
    (V/'repair-rpc-private.json').write_text(json.dumps(raw))
    verdict={'verdict':'passed' if len(results)==4 else 'incomplete','transitions':results,'native_product_exit':product.returncode if product else None,'unexpected_provider_requests':len(requests),'memory_before':mem_before,'memory_after':memory(),'elapsed_seconds':round(time.monotonic()-started,2),'scope':'four remaining restoration transitions only; one isolated native omp runtime; no worker pane or operator home','limits':['Restoration arm/host timing controlled by local barriers; actual extension callbacks, owned retirement, watcher lock, wake queue and daemon consumer executed.','Prior recorded composer and quiet/re-arm evidence reused, not rerun.']}
    (EVIDENCE/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')

